import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Dictionary
{
    public static void main(String[] args)throws Exception 
    {
        Scanner sc=new Scanner(System.in);
        int choice;
        do
        {
            System.out.println("Enter choice:\n1.Enter word-meaning\n2.Search a word-meaning\n3.Delete a word-meaning\n4.Exit");
            choice=sc.nextInt();
            switch(choice)
            {
                case 1:
                    System.out.println("Enter word:");
                    String word=sc.next();
                    System.out.println("Enter meaning:");
                    String meaning=sc.nextLine();
                    sc.nextLine();
                    FileWriter fw=new FileWriter("dictionary.txt",true);
                    fw.write(" "+word+": "+meaning+"\n");
                    fw.close();
                    break;

                case 2:
                    System.out.println("Enter word to search:");
                    InputStreamReader isr=new InputStreamReader(System.in);
                    BufferedReader br=new BufferedReader(isr);
                    String data=br.readLine();
                    FileReader fr=new FileReader("dictionary.txt");
                    BufferedReader br1=new BufferedReader(fr);
                    String output=br1.readLine();
                    break;
                case 3:
                    
                    break;
                case 4:
                    System.exit(0);
            }
        }
        while(choice!=0);
       }
}
