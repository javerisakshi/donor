import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;

public class SerachDonor {
    public static void main(String[] args) {
        try
        {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter username-");
        String username=sc.next();
        Class.forName("com.mysq.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("select* from usersignup where username=?");
        st.setString(1,username);
        ResultSet rs=st.executeQuery();
        
        if(rs.next())
                {
                    String fullname=rs.getString(2);
                    long contactno=rs.getLong(3);
                    long alternateno=rs.getLong(4);
                    String email=rs.getString(5);
                    String bloodgroup=rs.getString(6);
                    String organ=rs.getString(7);
                    String address=rs.getString(8);
                    System.out.println(fullname+""+contactno+""+alternateno+""+email+""+bloodgroup+""+organ+""+address);
                }
        else
        {
            System.out.println("No records found");
        }
        }
        catch(SQLException | ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
    }
}
