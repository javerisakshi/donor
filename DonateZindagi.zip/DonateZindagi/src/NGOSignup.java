import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;


public class NGOSignup{
    public static void main(String...ar)throws Exception
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter ngo name-");
        String ngoName=sc.nextLine();
        System.out.println("Enter ngo registration id-");
        long ngoRegId=sc.nextLong();
        System.out.println("Enter password-");
        String password=sc.next();
        System.out.println("Enter confirm password-");
        String confirmPassword=sc.next();
        if(password.equals(confirmPassword))
        {
            System.out.println("password matched");
        }
        else
        {
            System.out.println("Password did not match");
        }
        System.out.println("Enter contact number-");
        long contactNo=sc.nextLong();
        System.out.println("Enter Email-ID-");
        String email=sc.nextLine();
        System.out.println("Enter Address-");
        String address=sc.nextLine();
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("insert into NGOsignup values(?,?,?,?,?,?,?)");
        
        st.setString(1,ngoName);
        st.setLong(2,ngoRegId);
        st.setString(3,password);
        st.setString(4,confirmPassword);
        st.setString(5,address);
        st.setLong(6,contactNo);
        st.setString(7,email);
        st.executeUpdate();
        con.close();
        System.out.println("Account created.");
    }
    
}
