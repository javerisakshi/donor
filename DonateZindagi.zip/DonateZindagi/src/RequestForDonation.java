import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;

public class RequestForDonation {
    public static void main(String...ar)throws Exception
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Patients Full name-");
        String patientName=sc.nextLine();
        System.out.println("Enter Required blood group-");
        String bloodGroup=sc.next();
        System.out.println("Enter required organ-");
        String organ=sc.next();
        System.out.println("Enter contact number-");
        long contactNo=sc.nextLong();
        System.out.println("Enter Address-");
        String location=sc.nextLine();
        System.out.println("Enter Patient's age-");
        int age=sc.nextInt();
        System.out.println("Enter patients condition-");
        String condition=sc.nextLine();
        System.out.println("Enter donation date-");
        int donationDate=sc.nextInt();
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("insert into requestfordonation values(?,?,?,?,?,?,?,?)");
        st.setString(1,patientName);
        st.setString(2,bloodGroup);
        st.setString(3,organ);
        st.setLong(4,contactNo);
        st.setString(5,location);
        st.setInt(6,age);
        st.setString(7,condition);
        st.setInt(8,donationDate);
        
        st.executeUpdate();
        con.close();
        System.out.println("Request Submitted.");
    }
    
}
