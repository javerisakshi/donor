import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.ResultSet;
import java.sql.Connection;

public class Update {
public static void main(String[] args) {
    try {
        {
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter username to update:");
            String username=sc.nextLine();
            
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con= DriverManager.getConnection("jdbc:mysql://loclhost:3306/donatezindagi","root","root");
            
            PreparedStatement st=con.prepareStatement("select* from usersignup where username=?");
            st.setString(1, username);
            
            ResultSet rs=st.executeQuery();
            
            if(rs.next())
            {
                String fullName=rs.getString(2);
                long contactNo=rs.getLong(3);
                long alternateNo=rs.getLong(4);
                String email=rs.getString(5);
                String bloodGroup=rs.getString(6);
                String organ=rs.getString(7);
                int dob=rs.getInt(8);
                String address=rs.getString(9);
                String city=rs.getString(10);
                String medicalHistory=rs.getString(11);
                boolean hivStatus=rs.getBoolean(12);
                boolean covidStatus=rs.getBoolean(13);
                boolean tattooStatus=rs.getBoolean(14);
                                     
            }
            else
            {
                System.out.println("No records found");
            }
        }
    } catch (SQLException | ClassNotFoundException ex) 
    {
            ex.printStackTrace();
    }
}
    
}
