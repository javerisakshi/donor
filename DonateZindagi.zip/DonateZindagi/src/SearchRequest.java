import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;

public class SearchRequest {
    public static void main(String[] args) {
        try {
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
                PreparedStatement st=con.prepareStatement("select* form requestfordonation");
                ResultSet rs=st.executeQuery();
                
                while(rs.next())
                {
                    String patientname=rs.getString(1);
                    String bloodgroup=rs.getString(2);
                    String organ=rs.getString(3);
                    long contactno=rs.getLong(4);
                    String location=rs.getString(5);
                    int patientage=rs.getInt(6);
                    boolean condition=rs.getBoolean(7);
                    int donationdate=rs.getInt(8);
                    System.out.println(patientname+""+bloodgroup+""+organ+""+contactno+""+location+""+patientage+""+condition+""+donationdate);
                }
                
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
}
