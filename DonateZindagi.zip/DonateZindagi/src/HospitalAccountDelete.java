import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;


public class HospitalAccountDelete {
    public static void main(String[] args) {
        try{
            
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter hospital registration id to delete-");
        String hospitalregid=sc.nextLine();
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("select* from hospitalsignup where username=?");
        st.setString(1,hospitalregid);
        ResultSet rs=st.executeQuery();
        if(rs.next())
        {
            PreparedStatement st1=con.prepareStatement("delete from hospitalsignup");
            st1.setString(1,hospitalregid);
            st1.executeUpdate();
            System.out.println("Account deleted.");
        }
        else
        {
            System.out.println("No record found to delete.");
        }
        }
        catch(SQLException | ClassNotFoundException ex){
                ex.printStackTrace();
                }
    }
}
