import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;


public class NGOAccountDelete {
    public static void main(String[] args) {
        try{
            
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter NGO registration id to delete-");
       long NGOregid=sc.nextLong();
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("select* from NGOsignup where username=?");
        st.setLong(1, NGOregid);
        ResultSet rs=st.executeQuery();
        if(rs.next())
        {
            PreparedStatement st1=con.prepareStatement("delete from NGOsignup");
            st1.setLong(1,NGOregid);
            st1.executeUpdate();
            System.out.println("Account deleted.");
        }
        else
        {
            System.out.println("No record found to delete.");
        }
        }
        catch(SQLException | ClassNotFoundException ex){

                ex.printStackTrace();
                }
    }
}
