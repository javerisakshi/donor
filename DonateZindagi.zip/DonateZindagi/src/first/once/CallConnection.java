package first.once;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CallConnection    
{
       static Connection con= null;
       static 
       {
           try
           {
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
           }
           catch(SQLException ex){}
       }
           static public Connection emergencyConnection()
           {
               try 
               {
                   if(con.isClosed())
                   {
                       con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
                   }
               }
               catch(SQLException ex){
               }
               return con;
           }
}
