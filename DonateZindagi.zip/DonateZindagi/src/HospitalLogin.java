import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;


public class HospitalLogin {
    public static void main(String[] args)throws Exception {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter hospital registration id-");
        long hospitalRegID=sc.nextLong();
        System.out.println("Enter password-");
        String password=sc.next();
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("select* from hospitalsignup where hospitalregid=? and password=?");
        ResultSet rs=st.executeQuery();
        if(rs.next())
        {
            st.setLong(1,hospitalRegID);
            st.setString(2,password);
            System.out.println("Login successfully");
        }
        else
        {
            System.out.println("invalid login details");
        }    
        con.close();
    }
}
