
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;


public class UserSignup {
    public static void main(String...ar)throws Exception
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Full name-");
        String fullName=sc.nextLine();
        System.out.println("Enter Username-");
        String username=sc.next();
        System.out.println("Enter password-");
        String password=sc.next();
        System.out.println("Enter confirm password-");
        String confirmPassword=sc.next();
        if(password.equals(confirmPassword))
        {
            System.out.println("password matched");
        }
        else
        {
            System.out.println("Password did not match");
        }
        System.out.println("Enter contact number-");
        long contactNo=sc.nextLong();
        System.out.println("Enter alternate contact number-");
        long alternateNo=sc.nextLong();
        System.out.println("Enter Email-ID-");
        String email=sc.nextLine();
        sc.nextLine();
        System.out.println("Enter Blood Group-");
        String bloodGroup=sc.nextLine();
        System.out.println("Organs you are willing to donate-");
        String organ=sc.nextLine();
        System.out.println("Enter Date of birth-");
        int birthDate=sc.nextInt();
        System.out.println("Enter Address-");
        String address=sc.nextLine();
        sc.nextLine();
        System.out.println("Enter city-");
        String city=sc.next();
        System.out.println("Enter Medical History-");
        String medicalHistory=sc.nextLine();
        sc.nextLine();
        System.out.println("Enter HIV positive Status-");
        boolean hivStatus=sc.nextBoolean();
        System.out.println("Enter COVID-19 vaccination status-");
        boolean covidStatus=sc.nextBoolean();
        System.out.println("Did you get tattooed in past 12 months-");
        boolean tattooStatus=sc.nextBoolean();
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("insert into usersignup values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        st.setString(1,fullName);
        st.setString(2,username);
        st.setString(3,password);
        st.setString(4,confirmPassword);
        st.setLong(5,contactNo);
        st.setLong(6,alternateNo);
        st.setString(7,email);
        st.setString(8,bloodGroup);
        st.setString(9,organ);
        st.setInt(10, birthDate);
        st.setString(11,address);
        st.setString(12,city);
        st.setString(13,medicalHistory);
        st.setBoolean(14,hivStatus);
        st.setBoolean(15,covidStatus);
        st.setBoolean(16,tattooStatus);
        st.executeUpdate();
        con.close();
        System.out.println("Account created.");
    }
    
}
