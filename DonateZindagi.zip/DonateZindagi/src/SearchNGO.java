import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;

public class SearchNGO {
    public static void main(String[] args) {
        try{
         Scanner sc=new Scanner(System.in);
        System.out.println("Enter NGO name-");
        String ngoName=sc.nextLine();
        Class.forName("com.mysq.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("select* from ngosignup where hospitalname=?");
        st.setString(1,ngoName);
        ResultSet rs=st.executeQuery();
        
        if(rs.next())
                {
                    String address=rs.getString(2);
                    long contactno=rs.getLong(3);
                    String email=rs.getString(4);
                    System.out.println(ngoName+""+address+""+contactno+""+email);
                }
        else
        {
            System.out.println("no record found");
        }
        }
        catch(SQLException | ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
    }
}
