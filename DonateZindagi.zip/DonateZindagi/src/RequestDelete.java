import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.DriverManager;


public class RequestDelete {
    public static void main(String[] args) {
        try{
            
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter patient name to delete-");
        String patientname=sc.nextLine();
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("select* from requestfordonation where patientname=?");
        st.setString(1,patientname);
        ResultSet rs=st.executeQuery();
        if(rs.next())
        {
            PreparedStatement st1=con.prepareStatement("delete from requestfordonation");
            st1.setString(1,patientname);
            st1.executeUpdate();
            System.out.println("Request deleted.");
        }
        else
        {
            System.out.println("No record found to delete.");
        }
        }
        catch(SQLException | ClassNotFoundException ex){
                ex.printStackTrace();
                }
    }
}
