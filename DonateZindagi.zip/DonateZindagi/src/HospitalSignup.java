import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class HospitalSignup{
    public static void main(String...ar)throws Exception
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter hospital name-");
        String hospitalName=sc.nextLine();
        System.out.println("Enter hospital registration id-");
        long hospitalRegId=sc.nextLong();
        System.out.println("Enter password-");
        String password=sc.next();
        System.out.println("Enter confirm password-");
        String confirmPassword=sc.next();
        if(password.equals(confirmPassword))
        {
            System.out.println("password matched");
        }
        else
        {
            System.out.println("Password did not match");
        }
        System.out.println("Enter contact number-");
        long contactNo=sc.nextLong();
        System.out.println("Enter city-");
        String city=sc.nextLine();
        System.out.println("Enter Address-");
        String address=sc.nextLine();
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/donatezindagi","root","root");
        PreparedStatement st=con.prepareStatement("insert into hospitalsighup values(?,?,?,?,?,?,?)");
        
        st.setString(1,hospitalName);
        st.setLong(2,hospitalRegId);
        st.setString(3,password);
        st.setString(4,confirmPassword);
        st.setString(5,address);
        st.setLong(6,contactNo);
        st.setString(7,city);
        st.executeUpdate();
        con.close();
        System.out.println("Account created.");
    }
    
}
